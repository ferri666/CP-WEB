let good = 0

while (!good)
{
    let passwd = prompt("Entra contrasenya:")
    if (passwd.length < 8)
        alert("La contraseña es molt curta")
    else if (passwd=="12345678" || passwd=="password" || passwd =="87654321")
        alert("La contraseña es molt obvia")
    else if (passwd.length>20)
        alert("La contraseña es molt llarga")
    else
        good=1
}
console.log("Contraseña guardada")